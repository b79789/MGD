//
//  EndScene.h
//  BirdyCatchv1
//
//  Created by Brian Stacks on 6/9/15.
//  Copyright (c) 2015 Brian Stacks. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface EndScene : SKScene

@end
