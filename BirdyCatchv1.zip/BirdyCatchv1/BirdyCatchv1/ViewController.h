//
//  ViewController.h
//  BirdyCatchv1
//
//  Created by Brian Stacks on 6/1/15.
//  Copyright (c) 2015 Brian Stacks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameScene.h"

@interface ViewController : UIViewController


@end

