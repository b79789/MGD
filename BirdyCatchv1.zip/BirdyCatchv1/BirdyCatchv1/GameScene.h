//
//  GameScene.h
//  BirdyCatchv1
//
//  Created by Brian Stacks on 6/2/15.
//  Copyright (c) 2015 Brian Stacks. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene<SKPhysicsContactDelegate>

@end
